<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>
    <h1>Hi <?php echo e($career->name); ?></h1>
    <p>Thank you for submitting form. we'll get back to you soon</p>
</body>
</html>
<?php /**PATH D:\xampp2\htdocs\xampp\prj\resources\views/mail/careerSubmited.blade.php ENDPATH**/ ?>