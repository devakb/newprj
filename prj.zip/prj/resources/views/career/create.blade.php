@extends('layouts.app')


@section('content')



<form id="form">

    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name">
        <p class="error_text text-danger"></p>
    </div>

    <div class="form-group">
        <label for="contact">Contact</label>
        <input type="text" class="form-control" id="contact" name="contact" placeholder="Enter Contact">
        <p class="error_text text-danger"></p>
    </div>

    <div class="form-group">
        <label for="email">Name</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email">
        <p class="error_text text-danger"></p>
    </div>

    <div class="form-group">
        <label for="tolal_experience">Total Experience</label>
        <input type="number" step="0.1" class="form-control" id="tolal_experience" name="tolal_experience" placeholder="Enter Total Experience">
        <p class="error_text text-danger"></p>
    </div>

    <div class="form-group">
        <label for="skillsets">Skillsets</label>
        <input type="text" step="0.1" class="form-control" id="skillsets" name="skillsets" placeholder="Enter skillsets">
        <p class="error_text text-danger"></p>
    </div>

    <div class="form-group">
        <label for="current_organization">Current Organization</label>
        <input type="text" step="0.1" class="form-control" id="current_organization" name="current_organization" placeholder="Enter current_organization">
        <p class="error_text text-danger"></p>
    </div>

    <div class="form-group">
        <label for="additional_remarks">Additional Remarks</label>
        <textarea class="form-control" id="additional_remarks" name="additional_remarks" rows="3"></textarea>
    </div>

    <div class="form-group">
        <label for="resume">Resume</label>
        <input type="file" step="0.1" class="form-control" id="resume" name="resume">
        <p class="error_text text-danger"></p>
    </div>

    <button id="submitform" class="btn btn-danger">SUBMIT</button>

</form>

@endsection
@section('scripts')
    <script>

        //submitform, form


        $('#submitform').click(function(e){
            e.preventDefault();

            let form = $("#form");

            $(this).attr('disabled', true);
            $(this).text("Submitting...");

            $.ajax({
                url: "{{ route('career.store') }}",
                type: "POST",
                data: new FormData(form[0]),
                contentType: false,
                processData: false,
                success: (r) => {
                    Swal.fire(
                        'Thank You',
                        'You have successfully submitted form. We will get back to you soon.',
                        'success'
                        )
                    form[0].reset();
                },
                error: (e) => {
                    let errors = e.responseJSON.errors;

                    Object.keys(errors).map((key) => {
                        if(!$("#"+key).hasClass('is-invalid')){
                            $("#"+key).addClass('is-invalid');
                        }
                        $("#"+key).next().text(errors[key][0]);
                    })

                },
                complete: () => {
                    $(this).attr('disabled', false);
                    $(this).text("SUBMIT");
                }
            });

        });

    </script>
@endsection
