<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class CareerSubmittedMail extends Mailable
{
    use Queueable, SerializesModels;

    private $career, $resume_path;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($career, $resume_path)
    {
        $this->career = $career;
        $this->resume_path = $resume_path;
    }

    /**
     * Get the message envelope.
     *
     * @return \Illuminate\Mail\Mailables\Envelope
     */
    public function envelope()
    {
        return new Envelope(
            subject: 'Career Submitted Mail',
        );
    }

    /**
     * Get the message content definition.
     *
     * @return \Illuminate\Mail\Mailables\Content
     */
    public function content()
    {
        return new Content(
            view: 'mail.careerSubmited',
            with: [
                'career' => $this->career,
            ],
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array
     */
    public function attachments()
    {
        return [
            $this->resume_path,
        ];
    }
}
