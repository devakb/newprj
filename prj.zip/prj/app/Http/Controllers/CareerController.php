<?php

namespace App\Http\Controllers;

use App\Models\Career;
use Illuminate\Http\Request;
use App\Mail\CareerSubmittedMail;
use Illuminate\Support\Facades\Mail;
use App\Http\Requests\StoreCareerRequest;

class CareerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {



    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         return view('career.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCareerRequest $request)
    {

        $fileName = time().$request->file('resume')->getClientOriginalName();
        $filePath = '/public/resumes';

        if(!is_dir($filePath)) {
            mkdir($filePath, 0777, true);
        }

        $request->file('resume')->storeAs($filePath, $fileName);

        $career =  Career::create($request->only([
            "name",
            "contact",
            "email",
            "tolal_experience",
            "skillsets",
            "current_organization",
            "additional_remarks",
        ]) + [
            "resume" => $fileName,
        ]);


        Mail::to("akbdeveloper01@gmail.com")->send(new CareerSubmittedMail($career, storage_path("app/" . $filePath.'/'.$fileName)));

        return response()->json([
            'success' => true,
            'message' => 'Your application has been submitted successfully.'
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Career  $career
     * @return \Illuminate\Http\Response
     */
    public function show(Career $career)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Career  $career
     * @return \Illuminate\Http\Response
     */
    public function edit(Career $career)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Career  $career
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Career $career)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Career  $career
     * @return \Illuminate\Http\Response
     */
    public function destroy(Career $career)
    {
        //
    }
}
